// menu toggle, lightbox, year
(function(){
  document.querySelectorAll('#year,#year2,#year3').forEach(function(el){ 
    if(el) el.textContent = new Date().getFullYear(); 
  });
  function toggleMenu(btnId){ 
    var btn=document.getElementById(btnId); 
    if(!btn) return; 
    btn.addEventListener('click', function(){ 
      var nav=document.querySelector('.nav'); 
      if(!nav) return; 
      nav.style.display = (nav.style.display==='flex') ? '' : 'flex'; 
    }); 
  }
  toggleMenu('menuBtn'); 
  toggleMenu('menuBtn2'); 
  toggleMenu('menuBtn3');
  var lb=document.getElementById('lightbox'), 
      lbContent=document.getElementById('lbContent'), 
      lbClose=document.getElementById('lbClose');
  if(lbClose){ 
    lbClose.addEventListener('click', function(){ 
      lb.setAttribute('aria-hidden','true'); 
      lbContent.innerHTML=''; 
    }); 
  }
  if(lb){ 
    lb.addEventListener('click', function(e){ 
      if(e.target===lb){ 
        lb.setAttribute('aria-hidden','true'); 
        lbContent.innerHTML=''; 
      } 
    }); 
  }
  document.addEventListener('keydown', function(e){ 
    if(e.key==='Escape'){ 
      if(lb){ 
        lb.setAttribute('aria-hidden','true'); 
        lbContent.innerHTML=''; 
      } 
    } 
  });
})();


// ✅ Lightbox function with YouTube + Google Drive + MP4 + fallback
window.openLightbox = function(url, isInline){
  var lb = document.getElementById('lightbox'),
      lbContent = document.getElementById('lbContent');
  if(!lb) return;
  lb.setAttribute('aria-hidden','false');
  lbContent.innerHTML = ''; // reset

  // inline mp4
  if(isInline && url.indexOf('.mp4') !== -1){
    var video = document.createElement('video');
    video.controls = true; 
    video.autoplay = true; 
    video.style.width='100%';
    var src = document.createElement('source'); 
    src.src = url; 
    src.type = 'video/mp4';
    video.appendChild(src); 
    lbContent.appendChild(video); 
    return;
  }

  // YouTube
  if(url.indexOf('youtube.com') !== -1 || url.indexOf('youtu.be') !== -1){
    var videoId = (url.split('v=')[1] || url.split('/').pop()).split('&')[0];
    var ifrY = document.createElement('iframe');
    ifrY.src = 'https://www.youtube.com/embed/'+videoId+'?autoplay=1';
    ifrY.setAttribute('frameborder','0'); 
    ifrY.setAttribute('allowfullscreen','');
    ifrY.style.width='100%'; 
    ifrY.style.height='520px';
    lbContent.appendChild(ifrY); 
    return;
  }

  // Google Drive
  if(url.indexOf('drive.google.com') !== -1){
    var ifr = document.createElement('iframe');
    ifr.src = url;
    ifr.setAttribute('frameborder','0');
    ifr.setAttribute('allow','autoplay; encrypted-media; fullscreen');
    ifr.setAttribute('allowfullscreen','');
    ifr.style.width='100%'; 
    ifr.style.height='520px';
    var loaded = false;
    ifr.onload = function(){ loaded = true; };
    lbContent.appendChild(ifr);

    // fallback link if not loaded
    setTimeout(function(){
      if(!loaded){
        var fallback = document.createElement('div');
        fallback.style.padding = '18px';
        fallback.style.color = '#fff';
        fallback.innerHTML = '<p>Preview could not load. <a href="'+url+'" target="_blank" style="color:#ffd;">Open in new tab</a></p>';
        lbContent.appendChild(fallback);
      }
    }, 2500);
    return;
  }

  // normal mp4 (non-inline)
  if(url.indexOf('.mp4') !== -1){
    var v = document.createElement('video'); 
    v.controls = true; 
    v.autoplay = true; 
    v.style.width='100%';
    var s = document.createElement('source'); 
    s.src = url; 
    s.type = 'video/mp4';
    v.appendChild(s); 
    lbContent.appendChild(v); 
    return;
  }

  // fallback for others
  var a = document.createElement('a'); 
  a.href = url; 
  a.target='_blank'; 
  a.textContent = 'Open resource';
  lbContent.appendChild(a);
};
